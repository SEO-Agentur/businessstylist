import NextAuth from 'next-auth';
import { authOptions } from '@/lib/auth/auth-options';

const handler = NextAuth(authOptions);

export async function GET(request: Request, context: { params: { nextauth: string[] } }) {
  return handler(request, context);
}

export async function POST(request: Request, context: { params: { nextauth: string[] } }) {
  return handler(request, context);
}
