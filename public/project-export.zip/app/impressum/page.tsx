import type { Metadata } from 'next';

export const metadata: Metadata = {
  title: 'Impressum | Businessstylist',
  robots: { index: true, follow: true },
  alternates: { canonical: '/impressum' },
};

export default function ImpressumPage() {
  return (
    <div className="section-padding bg-business-cream">
      <div className="container-custom max-w-4xl">
        <h1 className="text-h1 mb-8">Impressum</h1>

        <div className="prose prose-lg max-w-none bg-white p-8 rounded-xl shadow-card">
          <h2>Angaben gemäß § 5 TMG</h2>
          <p>
            businesstylist.de<br />
            Anika Schmitz<br />
            Bay Blue 2<br />
            Triq il Marfa, MLH, 9065<br />
            Mellieha, Malta
          </p>

          <h2>Vertreten durch</h2>
          <p>Anika Schmitz</p>

          <h2>Kontakt</h2>
          <p>
            Telefon: +356 9968 3337<br />
            E-Mail: info@businessstylist.de
          </p>

          <h2>Umsatzsteuer-ID</h2>
          <p>
            Umsatzsteuer-Identifikationsnummer gemäß §27a Umsatzsteuergesetz: 28448304
          </p>

          <h2>Verantwortlich für den Inhalt nach § 55 Abs. 2 RStV</h2>
          <p>
            C. Badde<br />
            Bay Blue 2<br />
            Triq il Marfa, MLH, 9065<br />
            Mellieha, Malta
          </p>

          <h2>Haftungsausschluss</h2>

          <h3>Haftung für Inhalte</h3>
          <p>
            Die Inhalte unserer Seiten wurden mit größter Sorgfalt erstellt. Für die Richtigkeit,
            Vollständigkeit und Aktualität der Inhalte können wir jedoch keine Gewähr übernehmen.
            Als Diensteanbieter sind wir gemäß § 7 Abs.1 TMG für eigene Inhalte auf diesen Seiten
            nach den allgemeinen Gesetzen verantwortlich. Nach §§ 8 bis 10 TMG sind wir als
            Diensteanbieter jedoch nicht verpflichtet, übermittelte oder gespeicherte fremde
            Informationen zu überwachen oder nach Umständen zu forschen, die auf eine rechtswidrige
            Tätigkeit hinweisen.
          </p>

          <h3>Haftung für Links</h3>
          <p>
            Unser Angebot enthält Links zu externen Webseiten Dritter, auf deren Inhalte wir keinen
            Einfluss haben. Deshalb können wir für diese fremden Inhalte auch keine Gewähr übernehmen.
            Für die Inhalte der verlinkten Seiten ist stets der jeweilige Anbieter oder Betreiber
            der Seiten verantwortlich.
          </p>

          <h3>Urheberrecht</h3>
          <p>
            Die durch die Seitenbetreiber erstellten Inhalte und Werke auf diesen Seiten unterliegen
            dem deutschen Urheberrecht. Die Vervielfältigung, Bearbeitung, Verbreitung und jede Art
            der Verwertung außerhalb der Grenzen des Urheberrechtes bedürfen der schriftlichen
            Zustimmung des jeweiligen Autors bzw. Erstellers.
          </p>
        </div>
      </div>
    </div>
  );
}
