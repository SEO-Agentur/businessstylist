import type { Metadata } from 'next';

export const metadata: Metadata = {
  title: 'Lookbook',
  robots: {
    index: false,
    follow: false,
    nocache: true,
    googleBot: {
      index: false,
      follow: false,
      noarchive: true,
      nosnippet: true,
      noimageindex: true,
    },
  },
};

export default function LookbookLayout({ children }: { children: React.ReactNode }) {
  return <>{children}</>;
}
